
import './App.css';
import { Routes,Route } from 'react-router-dom';
import Banner from './component/BannerComponent/Banner';
import Nav from './component/NavComponent/Nav';
import Header from './component/HeaderComponent/Header';
import Sidebar from './component/SidebarComponent/Sidebar';
import Footer from './component/FooterComponent/Footer';
import Home from './component/HomeComponent/Home';
import Contact from './component/ContactComponent/Contact';
import Login from './component/LoginComponent/Login';
import Register from './component/RegisterComponent/Register';
import About from './component/AboutComponent/About';
import Services from './component/ServiceComponent/Services';
import UserHome from './component/UserHome/UserHome.js';
import AdminHome from './component/AdminComponent/AdminHome.js';
import Logout from './component/LogoutComponent/Logout.js';
import React from 'react';
import ManageUser from './component/ManageUserComponent/ManageUser.js';
import EpAdmin from './component/EpAdminComponent/EpAdmin.js';
import Verifyuser from './component/VerifyuserComponent/Verifyuser.js';




function App() {
  return(
    <>
    <Nav/>
    <Banner/>
    <Routes>  {/* Ensuring only one route is active at a time */}
        <Route path="/" element={<Home />} />
        <Route path="/about" element={<About />} />
        <Route path="/register" element={<Register />} />
        <Route path="/login" element={<Login />} />
        <Route path="/services" element={<Services />} />
        <Route path="/contact" element={<Contact />} /> {/* Fixed spelling */}
        <Route path="/admin" element={<AdminHome />} /> 
        <Route path="/user" element={<UserHome />} /> 
        <Route path="/logout" element={<Logout />} />
        <Route path="/manageuser" element={<ManageUser />} />
        <Route path="/epadmin" element={<EpAdmin />} />
        <Route path="/verifyuser/:email" element={<Verifyuser />} />
  
      

        
        


      </Routes>
    <div id="container">
    </div>
    </>
  );
  
}

export default App;
