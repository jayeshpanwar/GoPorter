import './Banner.css';
import { useState, useEffect } from 'react';

function Banner() {
  const [bannerContent, setBannerContent] = useState();

  useEffect(() => {
    const interval = setInterval(() => {
      if (
        localStorage.getItem('role') === 'admin' ||
        localStorage.getItem('role') === 'user'
      ) {
        // Add dynamic content logic here if needed
      }
    }, 1000);

    return () => clearInterval(interval); // Clean up interval
  }, []);

  return (
    <div id="Main">
      <div className="carousel-inner">
        <div className="carousel-item active">
          <img
            src="/assets/img/packers.jpg"
            width="100%"
            height="400px"
            alt="Banner"
          />
          <div className="carousel-caption d-flex align-items-center justify-content-center">
            <div className="container">
              <div className="row align-items-center">
                {/* LEFT TEXT CONTENT */}
                <div className="col-lg-7 text-white">
                  <h1 className="display-4 fw-bold">
                    Your Lightning Fast<br />
                    Delivery Partner
                  </h1>
                  <p
                    className="text-white-50 mt-3"
                    style={{ maxWidth: '650px' }}
                  >
                    Facere distinctio molestiae nisi fugit tenetur repellat non
                    praesentium nesciunt optio quis sit odio nemo quisquam.
                    eius quos reiciendis eum vel eum voluptatem eum maiores
                    eaque id optio ullam occaecati odio est possimus vel
                    reprehenderit.
                  </p>

                  {/* Search Bar */}
                  <div
                    className="input-group my-4 shadow"
                    style={{ maxWidth: '500px' }}
                  >
                    <input
                      type="text"
                      className="form-control"
                      placeholder="Your ZIP code or City. e.g. New York"
                    />
                    <button className="btn btn-primary">Search</button>
                  </div>

                  {/* Stats */}
                  <div className="d-flex gap-4 flex-wrap mt-4">
                    <div>
                      <h2 className="fw-bold text-white">232</h2>
                      <p className="text-white-50 mb-0">Clients</p>
                    </div>

                    <div>
                      <h2 className="fw-bold text-white">521</h2>
                      <p className="text-white-50 mb-0">Projects</p>
                    </div>
                    <div>
                      <h2 className="fw-bold text-white">1453</h2>
                      <p className="text-white-50 mb-0">Support</p>
                    </div>
                    <div>
                      <h2 className="fw-bold text-white">32</h2>
                      <p className="text-white-50 mb-0">Workers</p>
                    </div>
                  </div>
                </div>

                {/* RIGHT IMAGE */}
              
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Banner;