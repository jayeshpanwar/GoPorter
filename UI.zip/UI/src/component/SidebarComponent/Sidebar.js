import './Sidebar.css';

function Sidebar() {
  return(
    <>
    <div id="Container">
      <h1>Sidebar Section</h1></div>
    </>
  );
}
export default Sidebar;