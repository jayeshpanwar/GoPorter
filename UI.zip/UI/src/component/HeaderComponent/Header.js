import './Header.css';

function Header() {
  return(
    <>
    <div id="Header">
    <img src="./assets/img/Porterlogo.jpg" alt="header-pic" />
  </div>
    </>
  );
}
export default Header;